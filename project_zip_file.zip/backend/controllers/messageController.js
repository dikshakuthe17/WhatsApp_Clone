// controllers/messageController.js
const Message = require('../models/Message');

exports.getConversations = async (req, res) => {
    const chats = await Message.aggregate([
        { $sort: { timestamp: 1 } },
        {
            $group: {
                _id: "$wa_id",
                name: { $last: "$name" },
                lastMessage: { $last: "$text" },
                lastTimestamp: { $last: "$timestamp" }
            }
        }
    ]);
    res.json(chats.map(chat => ({
        _id: { wa_id: chat._id, name: chat.name },
        lastMessage: chat.lastMessage,
        lastTimestamp: chat.lastTimestamp
    })));
};

exports.getMessagesByUser = async (req, res) => {
    const messages = await Message.find({ wa_id: req.params.wa_id }).sort({ timestamp: 1 });
    res.json(messages);
};

exports.sendMessage = async (req, res) => {
    const { wa_id, name, text } = req.body;
    const newMsg = await Message.create({
        wa_id,
        name,
        message_id: `local-${Date.now()}`,
        text,
        timestamp: Date.now().toString(),
        status: 'sent'
    });
    res.json(newMsg);
};

